
package com.mycompany.conexao;

public interface EntidadeBase {

    public Integer getId();
}

